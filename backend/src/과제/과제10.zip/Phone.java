package 과제.과제10;

public class Phone {
	private App[] app;
	private Battery battery;
	public App[] getApp() {
		return app;
	}
	public void setApp(App[] app) {
		this.app = app;
	}
	public Battery getBattery() {
		return battery;
	}
	public void setBattery(Battery battery) {
		this.battery = battery;
	}
	

	
}
